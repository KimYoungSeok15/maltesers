<template>
  <div class="">
    <NavigationBar/>
    <h2 class="fw-semibold bg-black py-3 m-0">오늘의 영화</h2>
    <div class="backdropcontainer-wrapper" style="height:1000px">
      <div class="backdropcontainer mx-auto" :style="{ backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5) ), url(https://image.tmdb.org/t/p/original${MostPopMovie.backdrop_path})`}">
        <div class="row box1">
          <img class="col-4 offset-4 donggle_poster" style="cursor: pointer;" @click="GoDetail(MostPopMovie.id)" :src="`https://image.tmdb.org/t/p/original${MostPopMovie.poster_path}`" alt="">
          <!-- <div class="col-4 bg-black h-50" style="--bs-bg-opacity: .2;"> 
            <h1 class="fw-bold">{{MostPopMovie.title}} </h1>
            <br>
            <p>평점 :{{MostPopMovie.vote_average}}</p>
            <p>개봉일 :{{MostPopMovie.release_date}}</p>
            <span v-for="genre in MostPopMovie.genres" :key="genre.id">{{genre.name}}  </span>
            <br>
            <br>
          </div> -->
          <br>
        </div>			
      </div>
    </div>
    <h2 class="fw-semibold bg-black py-3">평점 높은 영화</h2>
    <br>
    <carousel-container :movies="RateSortedMovies"></carousel-container>

    <br>
    <h2 class="fw-semibold bg-black py-3">최신 영화</h2>
    <br>
    <carousel-container :movies="LatestSortedMovies"></carousel-container>

    <br>
    <h2 class="fw-semibold bg-black py-3">인기 영화</h2>
    <br>
    <carousel-container :movies="PopularitySortedMovies"></carousel-container>

    <br>

	</div>	
</template>

<script>
import NavigationBar from '@/components/NavigationBar.vue'
import CarouselContainer from '@/components/CarouselContainer.vue'
import axios from 'axios'
export default {
  components: {
    NavigationBar,
		CarouselContainer
  },
  data() {
    return {
      movieAll: '',
      RateSortedMovies: '',
      LatestSortedMovies: '',
      PopularitySortedMovies: '',
      PopMovies: '',
      MostPopMovie: null
    }
  },
  computed: {
    isLogin() {
      return this.$store.getters.isLogin
    }
  },
  methods: {
    calculateScore(movie) {
      let score = 0

      // adult 점수 계산
      if (movie.adult === false) {
        score += 10
      }

      // original_language 점수 계산
      if (movie.original_language === "ko") {
        score += 30
      } else if (movie.original_language === "en") {
        score += 10
      }

      // popularity 점수 계산
      score += Math.floor(movie.popularity / 100);

      // vote_average 점수 계산
      score += Math.round(movie.vote_average * 10)

      // vote_count 점수 계산
      score += Math.floor(movie.vote_count / 100)

      return score
    },
		GoDetail(movieId){
			this.$router.push(`detail/${movieId}`)
		}
  },
  created() {
		const TMDB_URL = `https://api.themoviedb.org/3/movie/popular?`		
    const djangoMovie = 'http://127.0.0.1:8000/api/m1/movies/'
		this.isLogin
    if (this.isLogin) {
			const params = {
				api_key: process.env.VUE_APP_Movie_API,
				language: 'ko-KR',
				region: 'KR',				
				page: '1'
			}			
			// TMDB에서 인기있는 영화들을 가져온다.
			axios({
				methods: 'get',
				url: TMDB_URL,
				params: params,
			})
			.then((res)=>{
				this.PopMovies = res.data.results
				let tempObj = [...res.data.results]
				tempObj.sort((a,b)=>new Date(a.release_date)- new Date(b.release_date))			
				let maxScore = 0
				for (const movie in this.PopMovies) {
					let score = this.calculateScore(this.PopMovies[movie])
					console.log(score, movie)
					for (const [index, mov] of tempObj.entries()){
						if (mov.release_date === this.PopMovies[movie].release_date){
							score += index
						}
					}
					if (score > maxScore) {
						maxScore = score
						this.MostPopMovie = this.PopMovies[movie]
					}
				}				
			})
		// 전체 영화를 Django DB에서 받아와서 Store에 저장
			axios({
			methods: 'get',
			url: djangoMovie,
		})
		.then((response) => {
		this.movieAll = response.data
		let temp1 = response.data
		let temp2 = response.data
		let temp3 = response.data
		temp1.sort((a,b)=>b.vote_average-a.vote_average)
		this.RateSortedMovies = temp1.slice(0,24)
		temp2.sort((a,b)=>new Date(b.release_date)- new Date(a.release_date))
		this.LatestSortedMovies = temp2.slice(0,24)
		temp3.sort((a,b)=>b.popularity-a.popularity)
		this.PopularitySortedMovies = temp3.slice(0,24)
		this.$store.dispatch('getAllMovies', this.movieAll)  
		})
		} 
		else {
        alert('로그인이 필요한 서비스 입니다')
        this.$router.push({ name: 'login'})
		}
	},

}

</script>

<style scoped>
.backdropcontainer-wrapper {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 110vh;
}

.backdropcontainer {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100vw;
  height: 50px;
  box-sizing: border-box;
  padding: 0px;
}
</style>
